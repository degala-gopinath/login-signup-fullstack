package com.example.loginsignup1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Loginsignup1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
