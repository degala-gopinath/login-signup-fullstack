package com.example.loginsignup1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Loginsignup1Application {

	public static void main(String[] args) {
		SpringApplication.run(Loginsignup1Application.class, args);
	}

}
