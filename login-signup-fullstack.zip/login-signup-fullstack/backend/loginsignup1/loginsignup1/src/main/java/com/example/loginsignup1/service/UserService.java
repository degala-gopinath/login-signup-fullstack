
package com.example.loginsignup1.service;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.loginsignup1.entity.User;
import com.example.loginsignup1.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Signup
    public String signup(String name, String email, String password) {

        email = email.trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            return "Email already registered!";
        }

        User user = new User();

        user.setName(name);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));

        userRepository.save(user);

        return "Signup successful!";
    }

    // Login
    public String login(String email, String password) {

        email = email.trim().toLowerCase();

        User user = userRepository.findByEmail(email)
                .orElse(null);

        if (user == null) {
            return "Invalid email or password!";
        }

        if (passwordEncoder.matches(password, user.getPassword())) {
            return "Login successful!";
        }

        return "Invalid email or password!";
    }
}
