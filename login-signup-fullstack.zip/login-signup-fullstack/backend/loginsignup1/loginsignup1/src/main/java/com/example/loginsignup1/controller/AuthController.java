
package com.example.loginsignup1.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.loginsignup1.service.UserService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {
	    "http://localhost:5173",
	    "http://localhost:5174",
	    "http://localhost:5175",
	    "http://localhost:5176",
	    "http://localhost:5178",
	    "http://localhost:5179"


})
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // Signup API
    @PostMapping("/signup")
    public ResponseEntity<String> signup(
            @RequestBody Map<String, String> request) {

        String name = request.get("name");
        String email = request.get("email");
        String password = request.get("password");

        if (name == null || name.isBlank()
                || email == null || email.isBlank()
                || password == null || password.isBlank()) {

            return ResponseEntity.badRequest()
                    .body("All fields are required!");
        }

        if (password.length() < 8) {
            return ResponseEntity.badRequest()
                    .body("Password must have at least 8 characters!");
        }

        String result = userService.signup(name, email, password);

        if (result.equals("Email already registered!")) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(result);
        }

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(result);
    }

    // Login API
    @PostMapping("/login")
    public ResponseEntity<String> login(
            @RequestBody Map<String, String> request) {

        String email = request.get("email");
        String password = request.get("password");

        if (email == null || email.isBlank()
                || password == null || password.isBlank()) {

            return ResponseEntity.badRequest()
                    .body("Email and password are required!");
        }

        String result = userService.login(email, password);

        if (result.equals("Login successful!")) {
            return ResponseEntity.ok(result);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(result);
    }
}
