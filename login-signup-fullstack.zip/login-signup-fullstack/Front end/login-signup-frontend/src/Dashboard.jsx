
function Dashboard({ onLogout }) {
  return (
    <div className="dashboard">
      <h2>Welcome to Your Dashboard!</h2>

      <p>You have logged in successfully.</p>

      <h3>My Account</h3>
      <p>Your account is ready to use.</p>

      <button type="button" onClick={onLogout}>
        Logout
      </button>
    </div>
  );
}

export default Dashboard;
