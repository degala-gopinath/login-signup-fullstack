
import { useState } from "react";
import Signup from "./Signup";
import Login from "./Login";
import Dashboard from "./Dashboard";
import "./App.css";

function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLoginSuccess = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setShowLogin(true);
  };

  if (loggedIn) {
    return (
      <div className="app">
        <Dashboard onLogout={handleLogout} />
      </div>
    );
  }

  return (
    <div className="app">
      <h1>Login & Signup Application</h1>

      {showLogin ? (
        <Login onLoginSuccess={handleLoginSuccess} />
      ) : (
        <Signup />
      )}

      <p>
        {showLogin
          ? "Don't have an account?"
          : "Already have an account?"}
      </p>

      <button
        type="button"
        onClick={() => setShowLogin(!showLogin)}
      >
        {showLogin ? "Go to Signup" : "Go to Login"}
      </button>
    </div>
  );
}

export default App;
